import arcpy
import pythonaddins
import pyperclip

def LocCopy():
    # get the current map document and the layer currently selected in TOC
    mxd = arcpy.mapping.MapDocument("CURRENT")
    df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]
    lyr = arcpy.mapping.ListLayers(mxd, pythonaddins.GetSelectedTOCLayerOrDataFrame())[0]
    try:
        matchcount = len(lyr.getSelectionSet())
    except:
        # error message if a layer and a row within that layer are not both selected
        pythonaddins.MessageBox("select both layer and row", "Error", {0})
    else:
        # check that only one row is selected
        if matchcount == 1:
            # create cursor for selected point
            with arcpy.da.UpdateCursor(lyr, ["count", "bluestrawberries", "x2", "y2", "SHAPE@X", "SHAPE@Y"]) as features:
                for feature in features:
                    # copy coordinates of point
                    lx = str(feature[4])
                    ly = str(feature[5])
                    location_text = ly + " " + lx
                    pyperclip.copy(location_text)

def pantonext():
    mxd = arcpy.mapping.MapDocument("CURRENT")
    df = arcpy.mapping.ListDataFrames(mxd, "Layers")[0]
    lyr = arcpy.mapping.ListLayers(mxd, pythonaddins.GetSelectedTOCLayerOrDataFrame())[0]
    with arcpy.da.SearchCursor(lyr, ["count"]) as features:
        for feature in features:
            # create query and select the next row based on the "count" field
            nextid = int(feature[0]) + 1
            expression = 'count = ' + str(nextid)
            exp2 = expression.replace("'", "")
            arcpy.SelectLayerByAttribute_management(lyr, "NEW_SELECTION", exp2)
            # move map view to centre on the next point at the same scale as is currently being used
            scalenow = df.scale
            df.extent = lyr.getSelectedExtent()
            df.scale = scalenow
            arcpy.RefreshActiveView()

class CopyLocation(object):
    """Implementation for tool1_addin.copy_location (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        LocCopy()

class NextPoint(object):
    """Implementation for tool1_addin.next_point (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pantonext()